Repacked for ATTinyCore 1.5.0 and later by Spence Konde / Azduino using the
binaries made available by @ArminJo at 
https://github.com/ArminJo/DigistumpArduino/archive/1.7.2.tar.gz
